declare const createApiClient: import("@vue-storefront/core").CreateApiClientFn;
export { createApiClient };
