declare const cookieParser: (headers: any) => any;
export { cookieParser };
