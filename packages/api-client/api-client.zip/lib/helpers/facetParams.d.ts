declare const facetParams: (filters: any) => string;
export { facetParams };
