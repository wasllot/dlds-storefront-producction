export default function setAddress(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
