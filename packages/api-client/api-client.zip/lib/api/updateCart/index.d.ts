export default function updateCart(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
} | {
    data?: undefined;
    cookieObject?: undefined;
}>;
