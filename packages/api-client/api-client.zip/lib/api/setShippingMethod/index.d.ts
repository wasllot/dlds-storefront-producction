export default function setShippingMethod(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
