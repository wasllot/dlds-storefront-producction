export default function updateCustomer(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
