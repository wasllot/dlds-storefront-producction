export default function addReview(context: any, params: any): Promise<{
    data: any;
}>;
