export default function fetchOrders(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
