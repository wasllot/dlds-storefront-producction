export default function removeFromCart(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
} | {
    data?: undefined;
    cookieObject?: undefined;
}>;
