export default function getCategoryProducts(context: any, params: any): Promise<any>;
