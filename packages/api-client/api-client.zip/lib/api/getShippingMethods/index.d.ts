export default function getShippingMethods(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
