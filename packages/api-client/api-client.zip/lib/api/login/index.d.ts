export default function login(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
