export default function addNewAddress(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
