export default function register(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
