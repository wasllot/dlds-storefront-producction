export default function getProduct(context: any, params: any): Promise<any>;
