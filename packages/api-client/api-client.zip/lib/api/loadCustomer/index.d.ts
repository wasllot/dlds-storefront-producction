export default function loadCustomer(context: any, params: any): Promise<any>;
