export default function makeOrder(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
