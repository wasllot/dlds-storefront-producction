export default function getAvailableCountries(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
