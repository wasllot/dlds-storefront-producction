export default function getPaymentMethods(context: any, params: any): Promise<{
    data: any;
    cookieObject: any;
}>;
