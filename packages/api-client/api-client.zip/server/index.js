'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var core = require('@vue-storefront/core');
var axios = require('axios');

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

var axios__default = /*#__PURE__*/_interopDefaultLegacy(axios);

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
const parsePsCookie = (str) => str
    .split(';')
    .slice(0, 1)
    .map(v => v.split('='))
    .reduce((acc, v) => {
    acc.vsfPsKeyCookie = decodeURIComponent(v[0] ? v[0].trim() : '');
    acc.vsfPsValCookie = decodeURIComponent(v[1] ? v[1].trim() : '');
    return acc;
}, {});
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
const cookieParser = (headers) => {
    // to get the latest Auth cookie - normally there are two PrestaShop cookies
    if (headers['set-cookie']) {
        const numberOfCookies = headers['set-cookie'].length;
        let cookieString = null;
        for (let i = 0; i < numberOfCookies; i++) {
            // prestashop cookies start with PrestaShop
            if (headers['set-cookie'][i].includes('PrestaShop')) {
                cookieString = headers['set-cookie'][i];
            }
        }
        return parsePsCookie(cookieString);
    }
    else {
        return null;
    }
};

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function bootstrap(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/lightbootstrap');
    url.searchParams.set('menu_with_images', 'single');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.get(url.href);
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

const replaceDashWithSpace = (word) => {
    return word.replace('-', ' ');
};
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
const facetParams = (filters) => {
    let urlString = '';
    let counter = 0;
    for (const facet in filters) {
        if (Object.prototype.hasOwnProperty.call(filters, facet)) {
            const filterArray = filters[facet];
            if (filterArray.length !== 0) {
                // eslint-disable-next-line max-depth
                if (counter !== 0) {
                    urlString += '/';
                }
                urlString += (replaceDashWithSpace(facet));
                // eslint-disable-next-line max-depth
                for (const filter of filterArray) {
                    urlString += ('-' + replaceDashWithSpace(filter));
                }
                counter++;
            }
        }
    }
    return urlString;
};

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function getCategoryProducts(context, params) {
    if (params.input.type && params.input.type === 'instant-search') {
        const url = new URL(context.config.api.url + params.lang + '/rest/productSearch');
        url.searchParams.set('iso_currency', params.currency);
        url.searchParams.set('s', params.input.term);
        url.searchParams.set('resultsPerPage', '20');
        const { data } = await context.client.get(url.href);
        return data;
    }
    else if (params.input.type && params.input.type === 'search') {
        const url = new URL(context.config.api.url + params.lang + '/rest/productSearch');
        url.searchParams.set('iso_currency', params.currency);
        url.searchParams.set('s', params.input.term);
        url.searchParams.set('resultsPerPage', '20');
        const { data } = await context.client.get(url.href);
        return data;
    }
    else if (params.input.type && params.input.type === 'featured') {
        const url = new URL(context.config.api.url + params.lang + '/rest/productsFeatured');
        url.searchParams.set('iso_currency', params.currency);
        url.searchParams.set('featured', params.input.featured ? params.input.featured : 1);
        url.searchParams.set('bestSelling', params.input.bestSelling ? params.input.bestSelling : 1);
        url.searchParams.set('resultsPerPage', params.input.resultsPerPage ? params.input.resultsPerPage : 20);
        const { data } = await context.client.get(url.href);
        return data;
    }
    else if (params.input.type && params.input.type === 'discount-products') {
        const url = new URL(context.config.api.url + params.lang + '/rest/productDiscount');
        url.searchParams.set('iso_currency', params.currency);
        url.searchParams.set('s', params.input.term);
        url.searchParams.set('page', params.input.page);
        const { data } = await context.client.get(url.href);
        return data;
    }
    else if (params.input.type && params.input.type === 'latest-products') {
        const url = new URL(context.config.api.url + params.lang + '/rest/latestProducts');
        url.searchParams.set('iso_currency', params.currency);
        url.searchParams.set('s', params.input.term);
        url.searchParams.set('page', params.input.page);
        const { data } = await context.client.get(url.href);
        return data;
    }
    else {
        const url = new URL(context.config.api.url + params.lang + '/rest/categoryProducts');
        url.searchParams.set('iso_currency', params.currency);
        const facetsUrl = facetParams(params.input.filters);
        url.searchParams.set('slug', params.input.categorySlug);
        url.searchParams.set('q', facetsUrl);
        url.searchParams.set('page', params.input.page);
        url.searchParams.set('with_all_images', '1');
        url.searchParams.set('with_category_tree', '1');
        url.searchParams.set('resultsPerPage', params.input.resultsPerPage ? params.input.resultsPerPage : '');
        const { data } = await context.client.get(url.href);
        return data;
    }
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function getProduct(context, params) {
    if (params.id) {
        const url = new URL(context.config.api.url + params.lang + '/rest/productdetail');
        url.searchParams.set('iso_currency', params.currency);
        params.id && url.searchParams.set('product_id', params.id);
        if (params.checkProduct && params.refresh) {
            if (params.groupId !== 0 && params.attrId !== 0) {
                url.searchParams.set(`group[${params.groupId}]`, params.attrId);
            }
            url.searchParams.set('quantity_wanted', params.qty);
            url.searchParams.set('refresh', params.refresh);
        }
        else if (params.refresh) {
            params.refresh && url.searchParams.set('refresh', params.refresh);
            for (const i in params.variantObj) {
                url.searchParams.set(`group[${i}]`, params.variantObj[i]);
            }
        }
        const { data } = await context.client.get(url.href);
        return data;
    }
    else if (params.featured) {
        const url = new URL(context.config.api.url + params.lang + '/rest/featuredproducts');
        console.log(url);
        const { data } = await context.client.get(url.href);
        return data;
    }
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function login(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/login');
    url.searchParams.set('iso_currency', params.currency);
    const { username, password, psCookieKey, psCookieValue } = params;
    const { data, headers } = await context.client.post(url.href, {
        email: username,
        password: password
    }, {
        headers: {
            Cookie: psCookieKey + '=' + psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function loadCustomer(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/accountInfo');
    url.searchParams.set('iso_currency', params.currency);
    const { data } = await context.client.get(url.href, {
        headers: {
            Cookie: params.key + '=' + params.value + ';'
        }
    });
    return data;
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function register(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/register');
    url.searchParams.set('iso_currency', params.currency);
    const { email, password, firstName, lastName, psCookieKey, psCookieValue } = params;
    const { data, headers } = await context.client.post(url.href, {
        email: email,
        password: password,
        firstName: firstName,
        lastName: lastName
    }, {
        headers: {
            Cookie: psCookieKey + '=' + psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function addToCart(context, params) {
    const { psCookieKey, psCookieValue, product, quantity } = params;
    const url = new URL(context.config.api.url + params.lang + '/rest/cart');
    url.searchParams.set('iso_currency', params.currency);
    url.searchParams.set('id_product', product.id);
    url.searchParams.set('qty', quantity);
    url.searchParams.set('id_product_attribute', product.attributeId);
    url.searchParams.set('op', 'up');
    url.searchParams.set('update', '1');
    url.searchParams.set('action', 'update');
    url.searchParams.set('image_size', 'medium_default');
    if (psCookieKey && psCookieValue) {
        const { data, headers } = await context.client.get(url.href, {
            headers: {
                Cookie: psCookieKey + '=' + psCookieValue + ';'
            }
        });
        const cookieObject = cookieParser(headers);
        return { data, cookieObject };
    }
    else {
        return {};
    }
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function getCartItems(context, params) {
    const { psCookieKey, psCookieValue } = params;
    const url = new URL(context.config.api.url + params.lang + '/rest/cart');
    url.searchParams.set('iso_currency', params.currency);
    url.searchParams.set('image_size', 'medium_default');
    if (psCookieKey && psCookieValue) {
        // It's not possible to get cart items without cookies (or any operation on cart)
        const { data, headers } = await context.client.get(url.href, {
            headers: {
                Cookie: psCookieKey + '=' + psCookieValue + ';'
            }
        });
        const cookieObject = cookieParser(headers);
        return { data, cookieObject };
    }
    else {
        return {};
    }
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function updateCart(context, params) {
    const { psCookieKey, psCookieValue, product, op } = params;
    const url = new URL(context.config.api.url + params.lang + '/rest/cart');
    url.searchParams.set('iso_currency', params.currency);
    url.searchParams.set('id_product', product.id);
    url.searchParams.set('id_product_attribute', product.productAttributeId);
    url.searchParams.set('qty', '1');
    url.searchParams.set('op', op);
    url.searchParams.set('update', '1');
    url.searchParams.set('action', 'update');
    url.searchParams.set('image_size', 'medium_default');
    if (psCookieKey && psCookieValue) {
        const { data, headers } = await context.client.get(url.href, {
            headers: {
                Cookie: psCookieKey + '=' + psCookieValue + ';'
            }
        });
        const cookieObject = cookieParser(headers);
        return { data, cookieObject };
    }
    else {
        return {};
    }
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function removeFromCart(context, params) {
    const { psCookieKey, psCookieValue, product } = params;
    const url = new URL(context.config.api.url + params.lang + '/rest/cart');
    url.searchParams.set('iso_currency', params.currency);
    url.searchParams.set('id_product', product.id);
    url.searchParams.set('id_product_attribute', product.productAttributeId);
    url.searchParams.set('image_size', 'medium_default');
    url.searchParams.set('delete', '1');
    url.searchParams.set('action', 'update');
    if (psCookieKey && psCookieValue) {
        const { data, headers } = await context.client.get(url.href, {
            headers: {
                Cookie: psCookieKey + '=' + psCookieValue + ';'
            }
        });
        const cookieObject = cookieParser(headers);
        return { data, cookieObject };
    }
    else {
        return {};
    }
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function loadAddresses(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/alladdresses');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.get(url.href, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function getReview(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/listcomments');
    url.searchParams.set('iso_currency', params.currency);
    params.productId && url.searchParams.set('id_product', params.productId);
    params.page && url.searchParams.set('page', params.page);
    const { data } = await context.client.get(url.href);
    return data;
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function addReview(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/postcomment');
    url.searchParams.set('iso_currency', params.currency);
    // eslint-disable-next-line camelcase
    const { id_product, comment_title, comment_content, criterion, key, value } = params;
    const { data } = await context.client.post(url.href, {
        // eslint-disable-next-line camelcase
        id_product: id_product,
        // eslint-disable-next-line camelcase
        comment_title: comment_title,
        // eslint-disable-next-line camelcase
        comment_content: comment_content,
        criterion: {
            1: criterion
        }
    }, {
        headers: {
            Cookie: key + '=' + value + ';'
        }
    });
    return { data };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function fetchOrders(context, params) {
    const { psCookieKey, psCookieValue, orderId } = params;
    const url = new URL(context.config.api.url + params.lang + '/rest/orderhistory');
    url.searchParams.set('iso_currency', params.currency);
    if (orderId) {
        url.searchParams.set('id_order', orderId);
    }
    if (psCookieKey && psCookieValue) {
        // It's not possible to get cart items without cookies (or any operation on cart)
        const { data, headers } = await context.client.get(url.href, {
            headers: {
                Cookie: psCookieKey + '=' + psCookieValue + ';'
            }
        });
        const cookieObject = cookieParser(headers);
        return { data, cookieObject };
    }
    else
        return null;
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function getAvailableCountries(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/addressform');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.get(url.href);
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function addNewAddress(context, params) {
    const { address } = params;
    const url = new URL(context.config.api.url + params.lang + '/rest/address');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.post(url.href, address, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function updateOneAddress(context, params) {
    const { address } = params;
    const url = new URL(context.config.api.url + params.lang + '/rest/address');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.post(url.href, address, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function removeAddress(context, params) {
    const { id } = params;
    const url = new URL(context.config.api.url + params.lang + '/rest/address');
    url.searchParams.set('iso_currency', params.currency);
    // eslint-disable-next-line camelcase
    const { data, headers } = await context.client.delete(url.href, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        },
        data: { id_address: id }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function setAddress(context, params) {
    const { id } = params;
    // eslint-disable-next-line camelcase
    const body = { id_address: id };
    const url = new URL(context.config.api.url + params.lang + '/rest/setaddresscheckout');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.post(url.href, body, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function getShippingMethods(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/carriers');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.get(url.href, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function setShippingMethod(context, params) {
    const { shippingMethodId, addressId } = params;
    // eslint-disable-next-line camelcase
    const body = { id_address: addressId, id_carrier: shippingMethodId };
    const url = new URL(context.config.api.url + params.lang + '/rest/setcarriercheckout');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.post(url.href, body, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function getPaymentMethods(context, params) {
    const url = new URL(context.config.api.url + params.lang + '/rest/paymentoptions');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.get(url.href, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function makeOrder(context, params) {
    const { methodName } = params;
    const url = new URL(context.config.api.url + params.lang + `/rest/${methodName}`);
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.get(url.href, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
async function updateCustomer(context, params) {
    const { updatedUserData } = params;
    const url = new URL(context.config.api.url + params.lang + '/rest/accountedit');
    url.searchParams.set('iso_currency', params.currency);
    const { data, headers } = await context.client.post(url.href, updatedUserData, {
        headers: {
            Cookie: params.psCookieKey + '=' + params.psCookieValue + ';'
        }
    });
    const cookieObject = cookieParser(headers);
    return { data, cookieObject };
}

var api = /*#__PURE__*/Object.freeze({
  __proto__: null,
  bootstrap: bootstrap,
  getCategoryProducts: getCategoryProducts,
  getProduct: getProduct,
  login: login,
  loadCustomer: loadCustomer,
  register: register,
  addToCart: addToCart,
  getCartItems: getCartItems,
  updateCart: updateCart,
  removeFromCart: removeFromCart,
  loadAddresses: loadAddresses,
  getReview: getReview,
  addReview: addReview,
  fetchOrders: fetchOrders,
  getAvailableCountries: getAvailableCountries,
  addNewAddress: addNewAddress,
  updateOneAddress: updateOneAddress,
  removeAddress: removeAddress,
  setAddress: setAddress,
  getShippingMethods: getShippingMethods,
  setShippingMethod: setShippingMethod,
  getPaymentMethods: getPaymentMethods,
  makeOrder: makeOrder,
  updateCustomer: updateCustomer
});

const onCreate = (settings) => {
    const client = axios__default["default"].create({
        baseURL: settings.api.url
    });
    return {
        config: {
            ...settings
        },
        client,
        cookies: (settings.api).cookies
    };
};
const { createApiClient } = core.apiClientFactory({
    onCreate,
    api
});

exports.createApiClient = createApiClient;
//# sourceMappingURL=index.js.map
